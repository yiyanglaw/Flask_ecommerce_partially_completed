import sqlite3

# Create a connection to the database
conn = sqlite3.connect('robots.db')

# Create a cursor object to execute SQL queries
c = conn.cursor()

# Create a table to store robot information
c.execute('''CREATE TABLE IF NOT EXISTS robots (
                id INTEGER PRIMARY KEY,
                name TEXT NOT NULL,
                qty INTEGER,
                price REAL,
                color TEXT,
                description TEXT
            )''')

# Sample data
robots = [
    (1, 'Robotic Manipulator', 5, 2500.00, 'Silver', 'A versatile robotic arm with multiple degrees of freedom.'),
    (2, 'Humanoid Robot', 3, 5000.00, 'White', 'An advanced humanoid robot capable of mimicking human movements and tasks.'),
    (3, 'Robotic Arm', 8, 1800.00, 'Black', 'A precise robotic arm suitable for industrial automation tasks.'),
    (4, 'Manipulator 2', 6, 3000.00, 'Yellow', 'An upgraded version of the original manipulator with improved accuracy and speed.'),
    (5, 'Robot Vacuum', 15, 400.00, 'Gray', 'An autonomous vacuum cleaner designed to clean various floor surfaces.'),
    (6, 'Robot Car', 12, 2000.00, 'Green', 'A self-driving car equipped with sensors and AI for navigation and safety.'),
    (7, 'Humanoid Robot 2', 4, 5500.00, 'Silver', 'An advanced version of the humanoid robot with enhanced AI capabilities.'),
    (8, 'Robot Toy', 25, 50.00, 'Various', 'A fun and interactive robot toy for children to play and learn with.')
]


# Insert sample data into the table
c.executemany('INSERT INTO robots VALUES (?, ?, ?, ?, ?, ?)', robots)

# Commit changes and close the connection
conn.commit()
conn.close()

from flask import Flask, render_template, request, redirect, url_for, session, jsonify
from flask_mail import Mail, Message  # Import Flask Mail for sending emails


import sqlite3
import bcrypt

app = Flask(__name__)
app.secret_key = 'your_secret_key'


# Configure Flask Mail settings
app.config['MAIL_SERVER'] = 'smtp.gmail.com'  # Update with your SMTP server
app.config['MAIL_PORT'] = 587  # Update with your SMTP port
app.config['MAIL_USE_TLS'] = True  # Enable TLS encryption
app.config['MAIL_USERNAME'] = 'your_email@example.com'  # Update with your email address
app.config['MAIL_PASSWORD'] = 'your_password'  # Update with your email password

# Initialize Flask Mail
mail = Mail(app)


# Function to create tables
def create_tables():
    conn = sqlite3.connect('robots.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS robots (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        qty INTEGER NOT NULL,
        price REAL NOT NULL,
        color TEXT NOT NULL,
        description TEXT NOT NULL)''')
    conn.commit()
    conn.close()

    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL UNIQUE,
        email TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL)''')
    conn.commit()
    conn.close()

    conn = sqlite3.connect('user_carts.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS carts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        product_id INTEGER NOT NULL,
        quantity INTEGER NOT NULL)''')
    conn.commit()
    conn.close()

# Function to fetch product data from the database
def get_product(product_id):
    conn = sqlite3.connect('robots.db')
    c = conn.cursor()
    c.execute("SELECT * FROM robots WHERE id = ?", (product_id,))
    product = c.fetchone()
    conn.close()

    if product:
        product_dict = {
            'id': product[0],
            'name': product[1],
            'qty': product[2],
            'price': product[3],
            'color': product[4],
            'description': product[5],
            'image': f"product{product_id}.jpg"
        }
        return product_dict
    else:
        return None

# Function to register a new user
def register_user(username, email, password):
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())
    c.execute("INSERT INTO users (username, email, password) VALUES (?, ?, ?)", (username, email, hashed_password))
    conn.commit()
    conn.close()

# Function to check if a username exists in the database
def username_exists(username):
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE username=?", (username,))
    user = c.fetchone()
    conn.close()
    return user is not None

# Function to authenticate user
# Function to authenticate user
def authenticate_user(username, password):
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute("SELECT id, password FROM users WHERE username=?", (username,))
    user = c.fetchone()
    conn.close()

    if user:
        stored_password = user[1]
        if bcrypt.checkpw(password.encode('utf-8'), stored_password):
            # Set username in session upon successful authentication
            session['username'] = username
            return True, user[0]  # Return user ID if authentication is successful

    return None, None  # Authentication failed

# Function to store cart information in the database
def store_cart_in_database(user_id, product_id, quantity):
    conn = sqlite3.connect('user_carts.db')
    c = conn.cursor()
    c.execute("SELECT quantity FROM carts WHERE user_id=? AND product_id=?", (user_id, product_id))
    existing_entry = c.fetchone()

    if existing_entry:
        new_quantity = existing_entry[0] + quantity
        c.execute("UPDATE carts SET quantity=? WHERE user_id=? AND product_id=?", (new_quantity, user_id, product_id))
    else:
        c.execute("INSERT INTO carts (user_id, product_id, quantity) VALUES (?, ?, ?)",
                  (user_id, product_id, quantity))
    conn.commit()
    conn.close()

# Function to fetch cart information from the database for a specific user
def fetch_cart_from_database(user_id):
    conn = sqlite3.connect('user_carts.db')
    c = conn.cursor()
    c.execute("SELECT product_id, SUM(quantity) FROM carts WHERE user_id=? GROUP BY product_id", (user_id,))
    rows = c.fetchall()
    cart_items = {}
    for row in rows:
        product_id, quantity = row
        product = get_product(product_id)
        if product:
            cart_items[product_id] = {
                'id': product_id,
                'name': product['name'],
                'price': product['price'],
                'quantity': quantity,
                'total': product['price'] * quantity
            }
    conn.close()
    return cart_items

# Function to update cart item quantity in the database
def update_cart_item_quantity(user_id, product_id, quantity):
    conn = sqlite3.connect('user_carts.db')
    c = conn.cursor()
    c.execute("UPDATE carts SET quantity=? WHERE user_id=? AND product_id=?", (quantity, user_id, product_id))
    conn.commit()
    conn.close()

# Function to remove cart item from the database
def remove_cart_item(user_id, product_id):
    conn = sqlite3.connect('user_carts.db')
    c = conn.cursor()
    c.execute("DELETE FROM carts WHERE user_id=? AND product_id=?", (user_id, product_id))
    conn.commit()
    conn.close()

# Function to calculate total price of items in the cart from the database
def calculate_cart_total_from_database(user_id):
    conn = sqlite3.connect('user_carts.db')
    c = conn.cursor()
    c.execute("SELECT SUM(robots.price * carts.quantity) FROM carts INNER JOIN robots ON carts.product_id = robots.id WHERE carts.user_id=?", (user_id,))
    total = c.fetchone()
    conn.close()
    return total[0] if total and total[0] else 0

# Function to clear cart for a user
def clear_cart_for_user(user_id):
    conn = sqlite3.connect('user_carts.db')
    c = conn.cursor()
    c.execute("DELETE FROM carts WHERE user_id=?", (user_id,))
    conn.commit()
    conn.close()

# Home route
@app.route('/')
def home():
    # Clear cart for the current user (if logged in)
    if 'user_id' in session:
        clear_cart_for_user(session['user_id'])
    return render_template('home.html')

# Shop route
@app.route('/shop')
def shop():
    conn = sqlite3.connect('robots.db')
    c = conn.cursor()
    c.execute("SELECT * FROM robots")
    rows = c.fetchall()
    products = []
    for row in rows:
        product = {
            'id': row[0],
            'name': row[1],
            'qty': row[2],
            'price': row[3],
            'color': row[4],
            'description': row[5],
            'image': f"product{row[0]}.jpg"
        }
        products.append(product)
    conn.close()
    return render_template('shop.html', products=products)

# Add to Cart route
@app.route('/add_to_cart', methods=['POST'])
def add_to_cart():
    if 'user_id' in session:
        product_id = request.form.get('product_id')
        quantity = request.form.get('quantity', type=int, default=1)
        store_cart_in_database(session['user_id'], product_id, quantity)
        return redirect(url_for('cart'))

# Cart route
@app.route('/cart', methods=['GET', 'POST'])
def cart():
    if 'user_id' in session:
        # Fetch cart information from the database for the logged-in user
        cart_items = fetch_cart_from_database(session['user_id'])
        total = calculate_cart_total_from_database(session['user_id'])
    else:
        # User is not logged in, show an empty cart
        cart_items = {}
        total = 0

    if request.method == 'POST':
        if request.form.get('action') == 'update':
            # Update quantity
            product_id = int(request.form['product_id'])
            quantity = int(request.form['quantity'])
            if 'user_id' in session:
                # User is logged in, update the quantity in the database
                update_cart_item_quantity(session['user_id'], product_id, quantity)

        elif request.form.get('action') == 'remove':
            # Remove item from cart
            product_id = int(request.form['product_id'])
            if 'user_id' in session:
                # User is logged in, remove the item from the database
                remove_cart_item(session['user_id'], product_id)

        return redirect(url_for('cart'))

    return render_template('cart.html', cart=cart_items.values(), total=total)

# Account route
@app.route('/account', methods=['GET', 'POST'])
def account():
    if request.method == 'POST':
        if 'register' in request.form:
            username = request.form['username']
            email = request.form['email']
            password = request.form['password']
            if not username_exists(username):
                register_user(username, email, password)
                session['logged_in'] = True
                session['user_id'], _ = authenticate_user(username, password)
                return redirect(url_for('account'))
            else:
                return render_template('account.html', message='Username already exists')

        elif 'login' in request.form:
            username = request.form['login_username']
            password = request.form['login_password']
            auth_success, user_id = authenticate_user(username, password)
            if auth_success:
                session['logged_in'] = True
                session['user_id'] = user_id
                session['username'] = username  # Set the username in session
                return redirect(url_for('account'))
            else:
                return render_template('account.html', message='Invalid username or password')

    else:
        if 'logged_in' in session and session['logged_in']:
            # User is already logged in
            return render_template('account.html', logged_in=True, username=session['username'])  # Pass the username to the template
        else:
            # User is not logged in
            return render_template('account.html', logged_in=False)

# Logout route
@app.route('/logout')
def logout():
    session.pop('logged_in', None)
    session.pop('user_id', None)
    session.pop('username', None)  # Clear the username from session
    return redirect(url_for('account'))


# About route
@app.route('/about')
def about():
    return render_template('about.html')

# Product route
@app.route('/product/<int:product_id>')
def product(product_id):
    product = get_product(product_id)
    if product:
        return render_template('product.html', product=product)
    else:
        return render_template('product_not_found.html')

# Payment route
@app.route('/payment')
def payment():
    # Check if the user is logged in
    if 'logged_in' not in session or not session['logged_in']:
        # User is not logged in, redirect to the account page
        return redirect(url_for('account'))

    # Get the cart total from the database
    total = calculate_cart_total_from_database(session['user_id'])
    return render_template('payment.html', total=total)

# Update cart item quantity (AJAX)
@app.route('/update_cart_item', methods=['POST'])
def update_cart_item():
    if 'user_id' in session:
        product_id = request.form['product_id']
        quantity = request.form['quantity']
        update_cart_item_quantity(session['user_id'], product_id, quantity)
        total = calculate_cart_total_from_database(session['user_id'])
        return jsonify({'success': True, 'total': total})
    else:
        return jsonify({'success': False})
    
    
# Add a route to display the suggestion page
@app.route('/suggestion')
def suggestion():
    return render_template('suggestion.html')

# Add a route to handle suggestion submission
@app.route('/submit_suggestion', methods=['POST'])
def submit_suggestion():
    # Get form data
    name = request.form['name']
    email = request.form['email']
    suggestion = request.form['suggestion']

    # Send email to website owner with the suggestion
    msg = Message('New Suggestion from Website',  # Email subject
                  sender=email,  # Use the user's email as the sender
                  recipients=['website_owner@example.com'])  # Update with website owner's email
    msg.body = f"Name: {name}\nEmail: {email}\n\nSuggestion:\n{suggestion}"

    # Send the email
    mail.send(msg)

    # Redirect to a thank you page or homepage
    return redirect(url_for('thank_you'))

# Add a route for the thank you page
@app.route('/thank_you')
def thank_you():
    return render_template('thank_you.html')

if __name__ == '__main__':
    create_tables()  # Create necessary tables
    app.run(debug=True, port=8095)